class DGMPolysLayer extends DGMAbstractLayer {
  constructor() {
    super();
    this.ClassName = "DGMPolysLayer";
  }
  Clear() {
    super.Clear();
  }
}
export default DGMPolysLayer;
