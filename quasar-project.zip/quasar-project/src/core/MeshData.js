class MeshData extends PIXI.MeshGeometry {
    constructor() {
        super();
        this.GeoType;
    }
}