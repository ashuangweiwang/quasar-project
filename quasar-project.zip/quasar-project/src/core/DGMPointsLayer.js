class DGMPointsLayer extends DGMAbstractLayer {
  constructor() {
    super();
    this.ClassName = "DGMPointsLayer";
  }
  Clear() {
    super.Clear();
  }
}
export default DGMPointsLayer;
