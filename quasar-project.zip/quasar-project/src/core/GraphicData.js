import * as PIXI from "pixi.js";
class GraphicData extends PIXI.GraphicsGeometry {
  constructor() {
    super();
    this.GeoType;
    this.FeatureID;
  }
}
export default GraphicData;
