class DGMCrossSection2D {
  constructor() {
    this.ClassName = "DGMCrossSection2D";
  }
}
export default DGMCrossSection2D;
